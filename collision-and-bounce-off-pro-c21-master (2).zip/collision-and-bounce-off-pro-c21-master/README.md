# collisionAlgorithm
Algorithm to detect collision between two objects
